# Block Fusion — Fabric 1.20.1

Mod Minecraft Java Edition Fabric yang menggabungkan dua blok kubus menjadi satu **Fusion Block** ketika piston diberi sinyal redstone.

## Cara menggabungkan blok

1. Pasang sebuah piston menghadap ke arah dua blok yang ingin digabungkan.
2. Letakkan dua blok kubus penuh tepat berurutan di depan piston.
3. Beri daya redstone ke piston (misalnya dengan tuas).
4. Blok yang paling dekat dengan piston akan dikonsumsi, sedangkan blok kedua berubah menjadi Fusion Block yang menyimpan kedua bahan.

Contoh susunan sebelum diberi daya:

```text
[Piston] -> [Diamond Ore] [Bedrock]
```

Hasilnya adalah satu Fusion Block yang menyimpan Diamond Ore + Bedrock. Bedrock juga dapat dipakai sebagai bahan karena penggabungan dilakukan sebelum piston menjalankan pergerakan vanilla.

## Tampilan dan penyimpanan

- Fusion Block dirender sebagai satu kubus dengan dua sisi material yang digabungkan (setengah kiri dan setengah kanan).
- Data kedua bahan disimpan sebagai BlockState di NBT Block Entity, jadi tetap tersimpan setelah dunia ditutup dan dibuka lagi.
- Saat Fusion Block dihancurkan, mod menjatuhkan item dari kedua bahan asal.
- Mod memakai satu blok dinamis, bukan mendaftarkan ribuan blok bernama permanen seperti `bedrock_ore`, `stone_diamond`, dan seterusnya.

## Blok yang didukung

Semua blok yang memiliki bentuk kubus penuh dan tidak mempunyai Block Entity dapat menjadi bahan, termasuk blok dari mod lain yang sudah terdaftar di game. Contoh: batu, tanah, kayu gelondongan, bijih, kaca penuh, obsidian, dan bedrock.

Blok seperti peti, tungku, slab, tangga, pagar, tanaman, cairan, dan blok lain yang bukan kubus penuh tidak digabungkan. Blok dengan Block Entity dikecualikan agar data inventori atau data khusus tidak hilang.

## Kompatibilitas

- Minecraft Java Edition 1.20.1
- Fabric Loader
- Fabric API
- Java 17

## Build lewat GitHub Actions (bisa dari Android)

1. Buat repository GitHub baru.
2. Upload seluruh isi folder proyek ini ke root repository. Pastikan `build.gradle`, `settings.gradle`, `src`, dan `.github` terlihat langsung di halaman utama repository.
3. Buka tab **Actions**.
4. Pilih workflow **Build Block Fusion** lalu tekan **Run workflow**, atau cukup lakukan commit/push.
5. Setelah selesai, buka hasil workflow dan unduh artifact bernama `Block-Fusion-Fabric-1.20.1`.
6. Ekstrak artifact, lalu ambil file `.jar` di dalamnya.
7. Letakkan `.jar` di folder `mods` Minecraft Java yang memakai Fabric 1.20.1 dan Fabric API.

## Catatan

Fusion Block adalah satu blok dengan dua material yang dirender berdampingan. Ia bukan blok registrasi baru untuk setiap pasangan, sehingga pasangan blok mod lain juga dapat digabung tanpa membuat file kode baru. Pemrosesan dilakukan saat piston mulai memanjang dan hanya menggabungkan dua blok tepat di depannya.
