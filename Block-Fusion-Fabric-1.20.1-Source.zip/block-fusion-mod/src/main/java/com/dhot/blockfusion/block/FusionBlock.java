package com.dhot.blockfusion.block;

import com.dhot.blockfusion.block.entity.FusionBlockEntity;
import com.dhot.blockfusion.block.entity.ModBlockEntities;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class FusionBlock extends BlockWithEntity {
    public FusionBlock(Settings settings) {
        super(settings);
    }

    @Override
    public BlockRenderType getRenderType(BlockState state) {
        // The block entity renderer draws the two ingredient blocks as joined halves.
        return BlockRenderType.INVISIBLE;
    }

    @Nullable
    @Override
    public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return new FusionBlockEntity(pos, state);
    }

    @Override
    public void onStateReplaced(BlockState state, World world, BlockPos pos, BlockState newState, boolean moved) {
        if (!world.isClient && !moved && !newState.isOf(this)) {
            BlockEntity blockEntity = world.getBlockEntity(pos);
            if (blockEntity instanceof FusionBlockEntity fusionBlockEntity) {
                fusionBlockEntity.dropIngredients();
            }
        }
        super.onStateReplaced(state, world, pos, newState, moved);
    }
}
