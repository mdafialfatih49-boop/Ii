package com.dhot.blockfusion.block.entity;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtHelper;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.BlockPos;
import net.minecraft.entity.ItemEntity;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class FusionBlockEntity extends BlockEntity {
    private BlockState firstIngredient = Blocks.STONE.getDefaultState();
    private BlockState secondIngredient = Blocks.COBBLESTONE.getDefaultState();

    public FusionBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.FUSION_BLOCK_ENTITY, pos, state);
    }

    public BlockState getFirstIngredient() {
        return firstIngredient;
    }

    public BlockState getSecondIngredient() {
        return secondIngredient;
    }

    public void setIngredients(BlockState first, BlockState second) {
        this.firstIngredient = first;
        this.secondIngredient = second;
        markDirty();

        if (world != null && !world.isClient) {
            world.updateListeners(pos, getCachedState(), getCachedState(), net.minecraft.block.Block.NOTIFY_LISTENERS);
        }
    }

    @Override
    protected void writeNbt(NbtCompound nbt) {
        super.writeNbt(nbt);
        nbt.put("FirstIngredient", NbtHelper.fromBlockState(firstIngredient));
        nbt.put("SecondIngredient", NbtHelper.fromBlockState(secondIngredient));
    }

    @Override
    public void readNbt(NbtCompound nbt) {
        super.readNbt(nbt);
        if (nbt.contains("FirstIngredient")) {
            firstIngredient = NbtHelper.toBlockState(Registries.BLOCK.getReadOnlyWrapper(), nbt.getCompound("FirstIngredient"));
        }
        if (nbt.contains("SecondIngredient")) {
            secondIngredient = NbtHelper.toBlockState(Registries.BLOCK.getReadOnlyWrapper(), nbt.getCompound("SecondIngredient"));
        }
    }

    @Override
    public NbtCompound toInitialChunkDataNbt() {
        return createNbt();
    }

    @Nullable
    @Override
    public Packet<ClientPlayPacketListener> toUpdatePacket() {
        return BlockEntityUpdateS2CPacket.create(this);
    }

    public void dropIngredients() {
        if (world == null || world.isClient) {
            return;
        }
        dropOne(firstIngredient);
        dropOne(secondIngredient);
    }

    private void dropOne(BlockState state) {
        Item item = state.getBlock().asItem();
        if (item == Items.AIR) {
            return;
        }
        ItemStack stack = new ItemStack(item);
        ItemEntity itemEntity = new ItemEntity(
                world,
                pos.getX() + 0.5,
                pos.getY() + 0.5,
                pos.getZ() + 0.5,
                stack
        );
        world.spawnEntity(itemEntity);
    }
}
