package com.dhot.blockfusion.block;

import com.dhot.blockfusion.BlockFusionMod;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModBlocks {
    public static final Block FUSION_BLOCK = new FusionBlock(
            AbstractBlock.Settings.copy(Blocks.STONE)
                    .strength(3.0f, 6.0f)
                    .sounds(BlockSoundGroup.STONE)
    );

    private ModBlocks() {
    }

    public static void register() {
        Registry.register(Registries.BLOCK, new Identifier(BlockFusionMod.MOD_ID, "fusion_block"), FUSION_BLOCK);
    }
}
