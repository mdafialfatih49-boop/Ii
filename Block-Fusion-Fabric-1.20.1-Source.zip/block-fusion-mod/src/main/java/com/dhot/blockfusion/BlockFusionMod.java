package com.dhot.blockfusion;

import com.dhot.blockfusion.block.ModBlocks;
import com.dhot.blockfusion.block.entity.ModBlockEntities;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BlockFusionMod implements ModInitializer {
    public static final String MOD_ID = "blockfusion";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModBlocks.register();
        ModBlockEntities.register();
        LOGGER.info("Block Fusion loaded: piston-based block combining is ready.");
    }
}
