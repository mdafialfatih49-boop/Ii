package com.dhot.blockfusion.block.entity;

import com.dhot.blockfusion.BlockFusionMod;
import com.dhot.blockfusion.block.ModBlocks;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModBlockEntities {
    public static final BlockEntityType<FusionBlockEntity> FUSION_BLOCK_ENTITY =
            Registry.register(
                    Registries.BLOCK_ENTITY_TYPE,
                    new Identifier(BlockFusionMod.MOD_ID, "fusion_block_entity"),
                    BlockEntityType.Builder.create(FusionBlockEntity::new, ModBlocks.FUSION_BLOCK).build(null)
            );

    private ModBlockEntities() {
    }

    public static void register() {
        // Accessing the field triggers static registration.
    }
}
