package com.dhot.blockfusion.mixin;

import com.dhot.blockfusion.block.ModBlocks;
import com.dhot.blockfusion.block.entity.FusionBlockEntity;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.PistonBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PistonBlock.class)
public abstract class PistonBlockMixin {
    /**
     * Runs just before vanilla calculates the piston movement. When two full
     * cube blocks are directly in front of the piston, it consumes the nearer
     * block and converts the farther block into a data-carrying Fusion Block.
     * This lets even normally immovable full cubes (for example bedrock) be
     * used as ingredients.
     */
    @Inject(method = "tryMove", at = @At("HEAD"))
    private void blockfusion$combineBlocks(World world, BlockPos pistonPos, BlockState pistonState, CallbackInfo ci) {
        if (world.isClient || pistonState.get(PistonBlock.EXTENDED)) {
            return;
        }

        Direction direction = pistonState.get(PistonBlock.FACING);
        BlockPos firstPos = pistonPos.offset(direction);
        BlockPos secondPos = pistonPos.offset(direction, 2);

        BlockState first = world.getBlockState(firstPos);
        BlockState second = world.getBlockState(secondPos);

        if (!isIngredient(world, firstPos, first) || !isIngredient(world, secondPos, second)) {
            return;
        }

        // Suppress normal drops: the Fusion Block will return both ingredients
        // when it is mined or destroyed later.
        int flags = Block.NOTIFY_LISTENERS | Block.SKIP_DROPS;
        world.setBlockState(firstPos, Blocks.AIR.getDefaultState(), flags);
        world.setBlockState(secondPos, ModBlocks.FUSION_BLOCK.getDefaultState(), flags);

        BlockEntity blockEntity = world.getBlockEntity(secondPos);
        if (blockEntity instanceof FusionBlockEntity fusionBlockEntity) {
            fusionBlockEntity.setIngredients(first, second);
        }
    }

    private static boolean isIngredient(World world, BlockPos pos, BlockState state) {
        return !state.isAir()
                && state.isFullCube(world, pos)
                && !state.hasBlockEntity()
                && !state.isOf(ModBlocks.FUSION_BLOCK);
    }
}
