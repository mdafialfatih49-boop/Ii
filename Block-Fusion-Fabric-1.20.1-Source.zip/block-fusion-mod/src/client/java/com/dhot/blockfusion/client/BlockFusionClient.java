package com.dhot.blockfusion.client;

import com.dhot.blockfusion.block.entity.ModBlockEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.BlockEntityRendererRegistry;

public class BlockFusionClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockEntityRendererRegistry.register(ModBlockEntities.FUSION_BLOCK_ENTITY, FusionBlockEntityRenderer::new);
    }
}
