package com.dhot.blockfusion.client;

import com.dhot.blockfusion.block.entity.FusionBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;

public class FusionBlockEntityRenderer implements BlockEntityRenderer<FusionBlockEntity> {
    public FusionBlockEntityRenderer(BlockEntityRendererFactory.Context context) {
    }

    @Override
    public void render(FusionBlockEntity entity, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vertexConsumers, int light, int overlay) {
        BlockRenderManager blockRenderer = MinecraftClient.getInstance().getBlockRenderManager();

        // Render the first ingredient as the left half of a cube.
        matrices.push();
        matrices.scale(0.5f, 1.0f, 1.0f);
        blockRenderer.renderBlockAsEntity(entity.getFirstIngredient(), matrices, vertexConsumers, light, overlay);
        matrices.pop();

        // Render the second ingredient as the right half of the same cube.
        matrices.push();
        matrices.translate(0.5, 0.0, 0.0);
        matrices.scale(0.5f, 1.0f, 1.0f);
        blockRenderer.renderBlockAsEntity(entity.getSecondIngredient(), matrices, vertexConsumers, light, overlay);
        matrices.pop();
    }
}
